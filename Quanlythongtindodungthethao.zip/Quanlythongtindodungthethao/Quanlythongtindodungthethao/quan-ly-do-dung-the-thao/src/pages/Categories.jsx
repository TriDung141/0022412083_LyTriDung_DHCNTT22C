import React, { useEffect, useState } from "react";
import Table from "../components/Table";
import axios from "axios";

const Categories = () => {
  const [categories, setCategories] = useState([]);

  const fetchCategories = async () => {
    try {
      const response = await axios.get("http://localhost:8081/loaidodung/all");
      setCategories(response.data);
    } catch (error) {
      console.error("Lỗi khi lấy danh sách loại đồ dùng:", error);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Danh Sách Loại Đồ Dùng</h2>
      <Table
        data={categories}
        columns={["id", "name", "description"]}
        onEdit={(category) => console.log("Edit", category)}
        onDelete={(id) => console.log("Delete", id)}
      />
    </div>
  );
};

export default Categories;