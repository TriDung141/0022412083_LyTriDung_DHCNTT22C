import React, { useState, useEffect } from "react";
import Table from "../components/Table";
import axios from "axios";

const Customers = () => {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    // Thay URL này bằng API của bạn
    axios.get("http://localhost:8081")
      .then((response) => {
        setCustomers(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

  const columns = ["id", "name", "email", "phone", "website"];

  return (
    <div>
      <h1>Customers</h1>
      <Table data={customers} columns={columns} />
    </div>
  );
};

export default Customers;