import React, { useEffect, useState } from "react";
import Table from "../components/Table";
import axios from "axios";

const Items = () => {
  const [items, setItems] = useState([]);

  const fetchItems = async () => {
    try {
      const response = await axios.get("http://localhost:8081/dodungthethao/all");
      setItems(response.data);
    } catch (error) {
      console.error("Lỗi khi lấy danh sách đồ dùng:", error);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Danh Sách Đồ Dùng Thể Thao</h2>
      <Table
        data={items}
        columns={["id", "name", "category", "brand", "price", "quantity"]}
        onEdit={(item) => console.log("Edit", item)}
        onDelete={(id) => console.log("Delete", id)}
      />
    </div>
  );
};

export default Items;