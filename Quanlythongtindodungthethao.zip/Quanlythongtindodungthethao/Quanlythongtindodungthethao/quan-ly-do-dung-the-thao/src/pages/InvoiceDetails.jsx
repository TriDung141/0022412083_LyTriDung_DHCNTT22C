import React, { useEffect, useState } from "react";
import Table from "../components/Table";
import axios from "axios";

const InvoiceDetails = () => {
  const [invoiceDetails, setInvoiceDetails] = useState([]);

  const fetchInvoiceDetails = async () => {
    try {
      const response = await axios.get("http://localhost:8081/chitiethoadon/all");
      setInvoiceDetails(response.data);
    } catch (error) {
      console.error("Lỗi khi lấy danh sách chi tiết hóa đơn:", error);
    }
  };

  useEffect(() => {
    fetchInvoiceDetails();
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Chi Tiết Hóa Đơn</h2>
      <Table
        data={invoiceDetails}
        columns={["id", "invoiceId", "itemId", "quantity", "price"]}
        onEdit={(detail) => console.log("Edit", detail)}
        onDelete={(id) => console.log("Delete", id)}
      />
    </div>
  );
};

export default InvoiceDetails;