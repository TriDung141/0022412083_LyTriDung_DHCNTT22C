import React, { useEffect, useState } from "react";
import Table from "../components/Table";
import axios from "axios";

const Invoices = () => {
  const [invoices, setInvoices] = useState([]);

  const fetchInvoices = async () => {
    try {
      const response = await axios.get("http://localhost:8081/hoadon/all");
      setInvoices(response.data);
    } catch (error) {
      console.error("Lỗi khi lấy danh sách hóa đơn:", error);
    }
  };

  useEffect(() => {
    fetchInvoices();
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Danh Sách Hóa Đơn</h2>
      <Table
        data={invoices}
        columns={["id", "customerId", "adminId", "total", "createdDate"]}
        onEdit={(invoice) => console.log("Edit", invoice)}
        onDelete={(id) => console.log("Delete", id)}
      />
    </div>
  );
};

export default Invoices;