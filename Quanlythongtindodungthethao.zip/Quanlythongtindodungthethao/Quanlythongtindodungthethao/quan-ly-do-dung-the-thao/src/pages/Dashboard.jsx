import React, { useEffect, useState } from "react";
import axios from "axios";
import ItemTable from "../components/ItemTable";
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
  const [items, setItems] = useState([]);
  const navigate = useNavigate();

  const fetchItems = async () => {
    try {
      const response = await axios.get("http://localhost:8081/items");
      setItems(response.data);
    } catch (error) {
      console.error("Lỗi khi lấy danh sách đồ dùng:", error);
    }
  };

  const handleEdit = (item) => {
    navigate(`/add-item`, { state: { item } });
  };

  const handleDelete = async (id) => {
    if (window.confirm("Bạn có chắc chắn muốn xóa đồ dùng này?")) {
      try {
        await axios.delete(`http://localhost:8081/items/${id}`);
        alert("Xóa thành công!");
        fetchItems();
      } catch (error) {
        console.error("Lỗi khi xóa đồ dùng:", error);
        alert("Có lỗi xảy ra khi xóa đồ dùng!");
      }
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Danh Sách Đồ Dùng Thể Thao</h2>
      <ItemTable items={items} onEdit={handleEdit} onDelete={handleDelete} />
    </div>
  );
};

export default Dashboard;