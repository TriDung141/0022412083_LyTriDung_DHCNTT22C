import React, { useEffect, useState } from "react";
import Table from "../components/Table";
import axios from "axios";

const Admins = () => {
  const [admins, setAdmins] = useState([]);

  const fetchAdmins = async () => {
    try {
      const response = await axios.get("http://localhost:8081/quantrivien/all");
      setAdmins(response.data);
    } catch (error) {
      console.error("Lỗi khi lấy danh sách quản trị viên:", error);
    }
  };

  useEffect(() => {
    fetchAdmins();
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Danh Sách Quản Trị Viên</h2>
      <Table
        data={admins}
        columns={["id", "username", "fullName", "email"]}
        onEdit={(admin) => console.log("Edit", admin)}
        onDelete={(id) => console.log("Delete", id)}
      />
    </div>
  );
};

export default Admins;