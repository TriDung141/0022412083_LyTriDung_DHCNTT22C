import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import ItemForm from "../components/ItemForm";
import axios from "axios";

const AddItem = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const itemToEdit = location.state?.item;

  const handleSubmit = async (formData) => {
    try {
      if (itemToEdit) {
        await axios.put(`http://localhost:8081${itemToEdit.id}`, formData);
        alert("Đồ dùng đã được cập nhật thành công!");
      } else {
        await axios.post("http://localhost:8081", formData);
        alert("Đồ dùng đã được thêm thành công!");
      }
      navigate("/");
    } catch (error) {
      console.error("Lỗi khi thêm/cập nhật đồ dùng:", error);
      alert("Có lỗi xảy ra!");
    }
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">{itemToEdit ? "Chỉnh Sửa Đồ Dùng" : "Thêm Đồ Dùng Mới"}</h2>
      <ItemForm initialData={itemToEdit || {}} onSubmit={handleSubmit} />
    </div>
  );
};

export default AddItem;