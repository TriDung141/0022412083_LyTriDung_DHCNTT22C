import React from "react";
import Customers from "./pages/Customers";

const App = () => {
  return (
    <div>
      <h1>Quản Lý Đồ Dùng Thể Thao</h1>
      <Customers />
    </div>
  );
};

export default App;