import React, { useState } from "react";

const ItemForm = ({ initialData = {}, onSubmit }) => {
  const [formData, setFormData] = useState({
    name: initialData.name || "",
    type: initialData.type || "",
    quantity: initialData.quantity || 0,
    price: initialData.price || 0,
    brand: initialData.brand || "",
    description: initialData.description || "",
    image: initialData.image || "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4 bg-gray-100 rounded-lg">
      <div>
        <label className="block mb-2 font-bold">Tên Đồ Dùng</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          className="border px-4 py-2 w-full rounded"
          required
        />
      </div>
      <div>
        <label className="block mb-2 font-bold">Loại Đồ Dùng</label>
        <input
          type="text"
          name="type"
          value={formData.type}
          onChange={handleChange}
          className="border px-4 py-2 w-full rounded"
          required
        />
      </div>
      <div>
        <label className="block mb-2 font-bold">Số Lượng</label>
        <input
          type="number"
          name="quantity"
          value={formData.quantity}
          onChange={handleChange}
          className="border px-4 py-2 w-full rounded"
          required
        />
      </div>
      <div>
        <label className="block mb-2 font-bold">Giá</label>
        <input
          type="number"
          name="price"
          value={formData.price}
          onChange={handleChange}
          className="border px-4 py-2 w-full rounded"
          required
        />
      </div>
      <div>
        <label className="block mb-2 font-bold">Hình Ảnh (URL)</label>
        <input
          type="text"
          name="image"
          value={formData.image}
          onChange={handleChange}
          className="border px-4 py-2 w-full rounded"
        />
      </div>
      <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
        {initialData.name ? "Cập Nhật" : "Thêm"}
      </button>
    </form>
  );
};

export default ItemForm;