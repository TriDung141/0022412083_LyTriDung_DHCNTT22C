import React from "react";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <header className="bg-blue-600 text-white p-4 flex justify-between items-center">
      <h1 className="text-xl font-bold">Quản Lý Thông Tin Đồ Dùng Thể Thao</h1>
      <nav className="flex space-x-4">
        <Link to="/" className="hover:underline">
          Trang Chủ
        </Link>
        <Link to="/admins" className="hover:underline">
          Quản Trị Viên
        </Link>
        <Link to="/categories" className="hover:underline">
          Loại Đồ Dùng
        </Link>
        <Link to="/items" className="hover:underline">
          Đồ Dùng
        </Link>
        <Link to="/customers" className="hover:underline">
          Khách Hàng
        </Link>
        <Link to="/invoices" className="hover:underline">
          Hóa Đơn
        </Link>
        <Link to="/invoice-details" className="hover:underline">
          Chi Tiết Hóa Đơn
        </Link>
      </nav>
    </header>
  );
};

export default Header;