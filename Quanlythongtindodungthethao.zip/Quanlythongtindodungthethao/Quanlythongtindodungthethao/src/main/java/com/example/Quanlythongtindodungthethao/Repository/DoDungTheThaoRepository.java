package com.example.Quanlythongtindodungthethao.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Quanlythongtindodungthethao.Entity.DoDungTheThao;

@Repository
public interface DoDungTheThaoRepository extends JpaRepository<DoDungTheThao, Long> {
    // Có thể thêm các phương thức tùy chỉnh nếu cần
}