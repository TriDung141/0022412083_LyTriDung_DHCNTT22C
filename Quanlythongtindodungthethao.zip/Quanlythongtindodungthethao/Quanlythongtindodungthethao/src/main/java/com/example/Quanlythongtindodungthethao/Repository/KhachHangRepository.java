package com.example.Quanlythongtindodungthethao.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Quanlythongtindodungthethao.Entity.KhachHang;

@Repository
public interface KhachHangRepository extends JpaRepository<KhachHang, Long> {
    // Có thể thêm các phương thức tùy chỉnh nếu cần
}