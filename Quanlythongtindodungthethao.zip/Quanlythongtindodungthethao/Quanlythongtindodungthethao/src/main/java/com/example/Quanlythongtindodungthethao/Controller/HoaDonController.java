package com.example.Quanlythongtindodungthethao.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Quanlythongtindodungthethao.Entity.HoaDon;
import com.example.Quanlythongtindodungthethao.Repository.HoaDonRepository;

@RestController
@RequestMapping("/api/hoadon")
@CrossOrigin(origins = "http://127.0.0.1:5500")
public class HoaDonController {

    @Autowired
    private HoaDonRepository hoaDonRepository;

    @GetMapping("/all")
    public List<HoaDon> getAllHoaDon() {
        return hoaDonRepository.findAll();
    }

    @PostMapping("/add")
    public HoaDon addHoaDon(@RequestBody HoaDon hoaDon) {
        return hoaDonRepository.save(hoaDon);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<HoaDon> updateHoaDon(@PathVariable Long id, @RequestBody HoaDon updatedHoaDon) {
        return hoaDonRepository.findById(id)
                .map(hoaDon -> {
                    hoaDon.setKhachHang(updatedHoaDon.getKhachHang());
                    hoaDon.setDoDungTheThao(updatedHoaDon.getDoDungTheThao());
                    hoaDon.setSoLuong(updatedHoaDon.getSoLuong());
                    hoaDon.setGiaTien(updatedHoaDon.getGiaTien());
                    return ResponseEntity.ok(hoaDonRepository.save(hoaDon));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Object> deleteHoaDon(@PathVariable Long id) {
        return hoaDonRepository.findById(id)
                .map(hoaDon -> {
                    hoaDonRepository.delete(hoaDon);
                    return ResponseEntity.ok().build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}