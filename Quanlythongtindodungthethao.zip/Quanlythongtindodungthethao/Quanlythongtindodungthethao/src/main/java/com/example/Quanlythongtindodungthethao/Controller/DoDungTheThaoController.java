package com.example.Quanlythongtindodungthethao.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Quanlythongtindodungthethao.Entity.DoDungTheThao;
import com.example.Quanlythongtindodungthethao.Repository.DoDungTheThaoRepository;

@RestController
@RequestMapping("/api/dodungthethao")
@CrossOrigin(origins = "http://127.0.0.1:5500")
public class DoDungTheThaoController {

    @Autowired
    private DoDungTheThaoRepository doDungTheThaoRepository;

    @GetMapping("/all")
    public List<DoDungTheThao> getAllDoDungTheThao() {
        return doDungTheThaoRepository.findAll();
    }

    @PostMapping("/add")
    public DoDungTheThao addDoDungTheThao(@RequestBody DoDungTheThao doDungTheThao) {
        return doDungTheThaoRepository.save(doDungTheThao);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<DoDungTheThao> updateDoDungTheThao(@PathVariable Long id, @RequestBody DoDungTheThao updatedDoDungTheThao) {
        return doDungTheThaoRepository.findById(id)
                .map(doDung -> {
                    doDung.setTenDoDung(updatedDoDungTheThao.getTenDoDung());
                    doDung.setLoaiDoDung(updatedDoDungTheThao.getLoaiDoDung());
                    doDung.setThuongHieu(updatedDoDungTheThao.getThuongHieu());
                    doDung.setGia(updatedDoDungTheThao.getGia());
                    doDung.setSoLuong(updatedDoDungTheThao.getSoLuong());
                    doDung.setMoTa(updatedDoDungTheThao.getMoTa());
                    doDung.setHinhAnh(updatedDoDungTheThao.getHinhAnh());
                    return ResponseEntity.ok(doDungTheThaoRepository.save(doDung));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Object> deleteDoDungTheThao(@PathVariable Long id) {
        return doDungTheThaoRepository.findById(id)
                .map(doDung -> {
                    doDungTheThaoRepository.delete(doDung);
                    return ResponseEntity.ok().build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}