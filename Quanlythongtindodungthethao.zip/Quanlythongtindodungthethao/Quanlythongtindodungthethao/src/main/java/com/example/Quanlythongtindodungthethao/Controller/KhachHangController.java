package com.example.Quanlythongtindodungthethao.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Quanlythongtindodungthethao.Entity.KhachHang;
import com.example.Quanlythongtindodungthethao.Repository.KhachHangRepository;

@RestController
@RequestMapping("/api/khachhang")
@CrossOrigin(origins = "http://127.0.0.1:5500")
public class KhachHangController {

    @Autowired
    private KhachHangRepository khachHangRepository;

    @GetMapping("/all")
    public List<KhachHang> getAllKhachHang() {
        return khachHangRepository.findAll();
    }

    @PostMapping("/add")
    public KhachHang addKhachHang(@RequestBody KhachHang khachHang) {
        return khachHangRepository.save(khachHang);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<KhachHang> updateKhachHang(@PathVariable Long id, @RequestBody KhachHang updatedKhachHang) {
        return khachHangRepository.findById(id)
                .map(khachHang -> {
                    khachHang.setHoTen(updatedKhachHang.getHoTen());
                    khachHang.setSoDienThoai(updatedKhachHang.getSoDienThoai());
                    khachHang.setEmail(updatedKhachHang.getEmail());
                    khachHang.setDiaChi(updatedKhachHang.getDiaChi());
                    return ResponseEntity.ok(khachHangRepository.save(khachHang));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Object> deleteKhachHang(@PathVariable Long id) {
        return khachHangRepository.findById(id)
                .map(khachHang -> {
                    khachHangRepository.delete(khachHang);
                    return ResponseEntity.ok().build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}