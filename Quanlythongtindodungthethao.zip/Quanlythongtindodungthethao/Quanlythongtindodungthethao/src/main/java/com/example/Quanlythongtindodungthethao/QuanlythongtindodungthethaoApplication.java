package com.example.Quanlythongtindodungthethao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuanlythongtindodungthethaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuanlythongtindodungthethaoApplication.class, args);
	}

}
