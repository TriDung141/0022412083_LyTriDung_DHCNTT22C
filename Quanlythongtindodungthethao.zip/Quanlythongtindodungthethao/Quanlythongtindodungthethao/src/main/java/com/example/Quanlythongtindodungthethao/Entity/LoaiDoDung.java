package com.example.Quanlythongtindodungthethao.Entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "LoaiDoDung")
public class LoaiDoDung {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MaLoai")
    private Long maLoai;

    @Column(name = "TenLoai", nullable = false, unique = true)
    private String tenLoai;

    @Column(name = "MoTa")
    private String moTa;

    @OneToMany(mappedBy = "loaiDoDung", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DoDungTheThao> doDungTheThaoList;

    // Getters and Setters
    public Long getMaLoai() {
        return maLoai;
    }

    public void setMaLoai(Long maLoai) {
        this.maLoai = maLoai;
    }

    public String getTenLoai() {
        return tenLoai;
    }

    public void setTenLoai(String tenLoai) {
        this.tenLoai = tenLoai;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public List<DoDungTheThao> getDoDungTheThaoList() {
        return doDungTheThaoList;
    }

    public void setDoDungTheThaoList(List<DoDungTheThao> doDungTheThaoList) {
        this.doDungTheThaoList = doDungTheThaoList;
    }
}