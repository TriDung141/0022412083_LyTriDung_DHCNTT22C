package com.example.Quanlythongtindodungthethao.Entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "DoDungTheThao")
public class DoDungTheThao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MaDoDung")
    private Long maDoDung;

    @Column(name = "TenDoDung", nullable = false)
    private String tenDoDung;

    @ManyToOne
    @JoinColumn(name = "MaLoai")
    private LoaiDoDung loaiDoDung;

    @Column(name = "ThuongHieu")
    private String thuongHieu;

    @Column(name = "Gia", precision = 10, scale = 2)
    private Double gia;

    @Column(name = "SoLuong", nullable = false)
    private Integer soLuong;

    @Column(name = "MoTa")
    private String moTa;

    @Column(name = "HinhAnh")
    private String hinhAnh;

    @OneToMany(mappedBy = "doDungTheThao", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<HoaDon> hoaDonList;

    // Getters and Setters
    public Long getMaDoDung() {
        return maDoDung;
    }

    public void setMaDoDung(Long maDoDung) {
        this.maDoDung = maDoDung;
    }

    public String getTenDoDung() {
        return tenDoDung;
    }

    public void setTenDoDung(String tenDoDung) {
        this.tenDoDung = tenDoDung;
    }

    public LoaiDoDung getLoaiDoDung() {
        return loaiDoDung;
    }

    public void setLoaiDoDung(LoaiDoDung loaiDoDung) {
        this.loaiDoDung = loaiDoDung;
    }

    public String getThuongHieu() {
        return thuongHieu;
    }

    public void setThuongHieu(String thuongHieu) {
        this.thuongHieu = thuongHieu;
    }

    public Double getGia() {
        return gia;
    }

    public void setGia(Double gia) {
        this.gia = gia;
    }

    public Integer getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(Integer soLuong) {
        this.soLuong = soLuong;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public String getHinhAnh() {
        return hinhAnh;
    }

    public void setHinhAnh(String hinhAnh) {
        this.hinhAnh = hinhAnh;
    }

    public List<HoaDon> getHoaDonList() {
        return hoaDonList;
    }

    public void setHoaDonList(List<HoaDon> hoaDonList) {
        this.hoaDonList = hoaDonList;
    }
}