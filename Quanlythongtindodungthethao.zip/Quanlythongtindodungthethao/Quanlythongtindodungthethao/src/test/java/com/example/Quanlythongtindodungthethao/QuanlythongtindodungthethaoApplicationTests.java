package com.example.Quanlythongtindodungthethao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanlythongtindodungthethaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
